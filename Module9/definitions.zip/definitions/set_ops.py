"""
Program: set_ops.py
Author: Bobby Parsons

Contains set-related functions
"""
def print_set(set_to_print):
    for item in set_to_print:
        print(item)