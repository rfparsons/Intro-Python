"""
Program: greeting.py
Author: Bobby Parsons

Contains greeting functions
"""
def hello_world():
    print("Hello!")

def credits():
    print("Author: Bobby Parsons")